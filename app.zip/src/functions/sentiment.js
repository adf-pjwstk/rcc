const { app } = require('@azure/functions');
const { TextAnalysisClient, AzureKeyCredential } = require('@azure/ai-language-text');

const endpoint = process.env.AZURE_LANGUAGE_ENDPOINT;
const apiKey = process.env.AZURE_LANGUAGE_KEY;

let client = null;
if (endpoint && apiKey) {
  client = new TextAnalysisClient(endpoint, new AzureKeyCredential(apiKey));
}

const UI_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Text Sentiment Analysis</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: #0b1325;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .card {
      background-color: #1e293b;
      width: 100%;
      max-width: 640px;
      padding: 36px;
      border-radius: 14px;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.45);
    }
    h1 {
      color: #38bdf8;
      font-size: 1.6rem;
      font-weight: 700;
      margin-bottom: 22px;
    }
    textarea {
      width: 100%;
      height: 140px;
      background-color: #111827;
      border: 1px solid #475569;
      border-radius: 8px;
      color: #e2e8f0;
      font-family: ui-monospace, SFMono-Regular, monospace;
      font-size: 0.95rem;
      padding: 14px 16px;
      resize: vertical;
      outline: none;
    }
    textarea:focus { border-color: #0284c7; }
    button {
      margin-top: 18px;
      width: 100%;
      padding: 12px 0;
      background-color: #0284c7;
      color: #ffffff;
      border: none;
      border-radius: 6px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
    }
    button:hover { background-color: #0369a1; }
    #result-panel {
      margin-top: 20px;
      padding: 14px 18px;
      border-radius: 6px;
      background-color: #111827;
      border: 1px solid #334155;
      color: #e2e8f0;
      font-family: ui-monospace, monospace;
      font-size: 0.88rem;
      display: none;
      white-space: pre-wrap;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>Text Sentiment Analysis</h1>
    <textarea id="textInput" placeholder="Enter text to analyze sentiment..."></textarea>
    <button id="analyzeBtn" onclick="submitAnalysis()">Analyze Sentiment</button>
    <div id="result-panel"></div>
  </div>

  <script>
    async function submitAnalysis() {
      const text = document.getElementById('textInput').value.trim();
      const panel = document.getElementById('result-panel');
      const btn = document.getElementById('analyzeBtn');

      if (!text) return;
      btn.disabled = true;
      btn.textContent = 'Analyzing with Azure AI...';

      try {
        const response = await fetch('/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text })
        });
        const data = await response.json();
        panel.style.display = 'block';
        panel.textContent = JSON.stringify(data, null, 2);
      } catch (err) {
        panel.style.display = 'block';
        panel.textContent = 'Error connecting to API: ' + err.message;
      } finally {
        btn.disabled = false;
        btn.textContent = 'Analyze Sentiment';
      }
    }
  </script>
</body>
</html>`;

app.http('index', {
  methods: ['GET'],
  authLevel: 'anonymous',
  route: '{*path}',
  handler: async () => {
    return {
      status: 200,
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
      body: UI_HTML
    };
  }
});

app.http('analyze', {
  methods: ['POST'],
  authLevel: 'anonymous',
  route: 'analyze',
  handler: async (request, context) => {
    let payload;
    try {
      payload = await request.json();
    } catch {
      return { status: 400, jsonBody: { error: 'Invalid JSON payload' } };
    }

    const text = payload && payload.text;
    if (!text) {
      return { status: 400, jsonBody: { error: 'Missing "text" property in request body' } };
    }

    if (!client) {
      context.error('Azure AI Language client credentials not found in environment.');
      return { status: 500, jsonBody: { error: 'Language service not configured.' } };
    }

    try {
      // Call Azure AI Language Text Analytics
      const [result] = await client.analyze("SentimentAnalysis", [text]);

      if (result.error) {
        throw new Error(result.error.message);
      }

      return {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
        jsonBody: {
          input: text,
          sentiment: result.sentiment, // positive, neutral, negative, or mixed
          confidenceScores: result.confidenceScores,
          sentences: result.sentences.map(s => ({
            text: s.text,
            sentiment: s.sentiment,
            confidenceScores: s.confidenceScores
          })),
          source: 'Azure AI Language'
        }
      };
    } catch (err) {
      context.error('Azure AI Language call failed:', err.message);
      return {
        status: 502,
        jsonBody: { error: 'Azure AI Language error', details: err.message }
      };
    }
  }
});
